# Mapster

## [1.8.4](https://github.com/Nevcairiel/Mapster/tree/1.8.4) (2019-08-10)
[Full Changelog](https://github.com/Nevcairiel/Mapster/compare/1.8.3...1.8.4)

- FogClear data for classic  
- Fix scaling adjustment on classic  
- Adjust the map Strata for classic  
- Setup Classic packaging  
